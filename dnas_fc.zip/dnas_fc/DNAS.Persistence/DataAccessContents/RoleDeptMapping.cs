﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class RoleDeptMapping
{
    public long MappingId { get; set; }

    public long? UserId { get; set; }

    public long? RoleId { get; set; }

    public string? DepartmentName { get; set; }
}
