﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class TempTbl
{
    public string? Col1 { get; set; }

    public string? Col2 { get; set; }
}
