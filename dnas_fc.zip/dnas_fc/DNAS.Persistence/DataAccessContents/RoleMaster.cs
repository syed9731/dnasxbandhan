﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class RoleMaster
{
    public long RoleId { get; set; }

    public string RoleName { get; set; } = null!;

    public bool IsActive { get; set; }
}
