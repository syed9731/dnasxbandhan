﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class Empl
{
    public string? Id { get; set; }

    public string? Name { get; set; }
}
