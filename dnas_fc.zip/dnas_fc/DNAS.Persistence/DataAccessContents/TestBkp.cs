﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class TestBkp
{
    public string? ExpenseIncurredAt { get; set; }

    public string? NatureofExpense { get; set; }
}
