﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class ImportDatum
{
    public string? Data { get; set; }
}
