﻿using System;
using System.Collections.Generic;

namespace DNAS.Persistence.DataAccessContents;

public partial class Role
{
    public string DesignationName { get; set; } = null!;
}
