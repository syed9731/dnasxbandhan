﻿namespace DNAS.Domian.DTO.CommonResponse
{
    public class CommonResp
    {
        public string? statuscode { get; set; }
        public string? message { get; set; }
    }
}
