﻿namespace DNAS.Domian.DTO.Confguration
{
    public class ConfigurationReqModel
    {
        public string ConfigurationKey { get; set; } = string.Empty;
    }
}
