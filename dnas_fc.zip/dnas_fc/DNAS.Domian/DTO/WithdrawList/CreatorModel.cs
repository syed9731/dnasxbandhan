﻿using DNAS.Domian.DTO.Note;

namespace DNAS.Domain.DTO.WithdrawList;

public class CreatorModel
{
    public IEnumerable<ApproversModel> approversModel { get; set; }=[];
}

