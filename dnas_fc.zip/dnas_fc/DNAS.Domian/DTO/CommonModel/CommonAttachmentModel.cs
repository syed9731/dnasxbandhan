﻿namespace DNAS.Domain.DTO.CommonModel
{
    public class CommonAttachmentModel
    {
        public string AttachmentId { get; set; } = string.Empty;
        public string NoteId { get; set; } = string.Empty;
        public string AttachmentPath { get; set; } = string.Empty;
        public string DocumentName { get; set; } = string.Empty;
    }
}
