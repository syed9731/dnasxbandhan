﻿namespace DNAS.Domian.DTO.Category
{
    public class CategoryRespModel
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public bool IsActive { get; set; }
    }
}
