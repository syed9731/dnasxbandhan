﻿namespace DNAS.Domian.DTO.Category
{
    public class CategoryReqModel
    {
        public string ontable { get; set; }=string.Empty;
        public int CategoryId { get; set; }
    }
}
