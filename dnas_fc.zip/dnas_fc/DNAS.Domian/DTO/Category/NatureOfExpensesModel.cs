﻿namespace DNAS.Domian.DTO.Category
{
    public class NatureOfExpensesModel
    {
        public string NatureOfExpensesId { get; set; } = string.Empty;
        public string ExpensesIncurredAtId { get; set; } = string.Empty;
        public string NatureOfExpensesName { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
    }
}
