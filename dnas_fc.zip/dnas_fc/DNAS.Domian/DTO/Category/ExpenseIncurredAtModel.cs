﻿namespace DNAS.Domian.DTO.Category
{
    public class ExpenseIncurredAtModel
    {
        public string ExpenseIncurredAtId { get; set; } = string.Empty;
        public string CategoryId { get; set; } = string.Empty;
        public string ExpenseIncurredAtName { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
    }
}
