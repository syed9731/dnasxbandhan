﻿using DNAS.Domian.DTO.Draft;

namespace DNAS.Domain.DAO.DbHelperModels.HeaderNotificationList
{
    public class ProcGetNotificationByUserOutput
    {
        public HederNotificationsList HederNotifications { get; set; } = new();
    }
}
