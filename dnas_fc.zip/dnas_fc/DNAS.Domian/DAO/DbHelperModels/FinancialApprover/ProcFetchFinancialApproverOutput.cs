﻿using DNAS.Domian.DTO.Login;

namespace DNAS.Domain.DAO.DbHelperModels.FinancialApprover
{
    public class ProcFetchFinancialApproverOutput
    {
        public IEnumerable<UserMasterModel> UserMasterModelList { get; set; } = [];
    }
}
