﻿namespace DNAS.Domian.DAO.DbHelperModels.MailConfiguration
{
    public class MailConfigModelInparam
    {
        public string @MailKey { get; set; } = string.Empty;
    }
}
