﻿namespace DNAS.Domain.DAO.DbHelperModels.DelegateByCreator
{
    public class ProcFetchDelegateByCreatorInparam
    {
        public string SearchKey { get; set; } = string.Empty;
        public string NoteId { get; set; } = string.Empty;
        public string OldApprover { get; set; } = string.Empty;
        public string CreatorId { get; set; } = string.Empty;
    }
}
