﻿using DNAS.Domian.DTO.Login;

namespace DNAS.Domain.DAO.DbHelperModels.VerifyRecoverPasswordUser
{
    public class ProcVerifyRecoverPasswordUserOutput
    {
        public ChangePasswordModel ChangePassword { get; set; } = new();
    }
}
