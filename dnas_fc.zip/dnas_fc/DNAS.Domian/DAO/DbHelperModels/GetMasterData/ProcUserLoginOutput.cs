﻿using DNAS.Domian.DTO.Login;

namespace DNAS.Domain.DAO.DbHelperModels.GetMasterData
{
    public class ProcUserLoginOutput
    {
        public UserMasterResponse UserMaster { get; set; } = new();
    }
}
