﻿using DNAS.Domian.DTO.Login;

namespace DNAS.Domain.DAO.DbHelperModels.RecomendedApprover
{
    public class RecomendedApproverOutput
    {
        public IEnumerable<UserMasterModel> UserMasterModelList { get; set; } = [];
    }
}
