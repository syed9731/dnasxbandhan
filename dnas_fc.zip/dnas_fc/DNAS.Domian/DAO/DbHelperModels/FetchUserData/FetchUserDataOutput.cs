﻿using DNAS.Domian.DTO.Login;

namespace DNAS.Domain.DAO.DbHelperModels.FetchUserData
{
    public class FetchUserDataOutput
    {
        public UserMasterModel UserMaster { get; set; } = new();
    }
}
