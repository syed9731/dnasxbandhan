﻿namespace DNAS.Domain.DAO.DbHelperModels.Attachment
{
    public class FetchAttachmentByNoteIdModel
    {
        public string @NoteId { get; set; } = string.Empty;
        public string @FileName {  get; set; } = string.Empty;
    }
}
