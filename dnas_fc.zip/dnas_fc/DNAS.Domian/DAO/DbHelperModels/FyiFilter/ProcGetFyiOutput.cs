﻿using DNAS.Domian.DTO.FYI;

namespace DNAS.Domian.DAO.DbHelperModels.FyiFilter
{
    public class ProcGetFyiOutput
    {
        public IEnumerable<FyiTable> Table { get; set; } = [];
    }
}
