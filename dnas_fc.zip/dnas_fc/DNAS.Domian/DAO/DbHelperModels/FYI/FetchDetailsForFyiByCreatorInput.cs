﻿namespace DNAS.Domain.DAO.DbHelperModels.FYI
{
    public class FetchDetailsForFyiByCreatorInput
    {
        public string @SearchKey { get; set; } = string.Empty;
        public string @NoteId { get; set; } = string.Empty;
    }
}
