﻿namespace DNAS.Domian.DAO.DbHelperModels.FYI
{
    public class ProcFetchUserAsPerEmailOrEmpIdInput
    {
        public string @SearchKey { get; set; } = string.Empty;
    }
}
