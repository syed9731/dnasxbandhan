﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DNAS.Domain.DAO.DbHelperModels.NoteVersion
{
    public class ProcFetchNoteVersionListByNoteIdInparam
    {
        public string @NoteId { get; set; } = string.Empty;
    }
}
