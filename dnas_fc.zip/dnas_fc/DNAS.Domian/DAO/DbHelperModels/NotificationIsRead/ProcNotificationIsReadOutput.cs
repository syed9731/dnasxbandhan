﻿namespace DNAS.Domian.DAO.DbHelperModels.NotificationIsRead
{
    public class ProcNotificationIsReadOutput
    {
        public DTO.Draft.Notification NotificationReadStatus { get; set; } = new();
    }
}
