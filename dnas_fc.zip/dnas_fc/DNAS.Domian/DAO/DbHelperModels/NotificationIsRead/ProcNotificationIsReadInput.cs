﻿namespace DNAS.Domian.DAO.DbHelperModels.NotificationIsRead
{
    public class ProcNotificationIsReadInput
    {
        public int @NotificationId { get; set; } = 0;
    }
}
