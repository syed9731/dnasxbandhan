﻿using DNAS.Domian.DTO.Confguration;

namespace DNAS.Domain.DAO.DbHelperModels.FetchConfiguration
{
    public class ProcFetchConfigurationOutput
    {
        public ConfigurationRespModel FetchConfiguration { get; set; } = new();
    }
}
