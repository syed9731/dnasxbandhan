﻿namespace DNAS.Domain.DAO.DbHelperModels.Approver
{
    public class ProcFetchForSkippByCreatorInput
    {
        public string NoteId { get; set; } = string.Empty;
        public string ApproverId { get; set; } = string.Empty;
    }
    
}
