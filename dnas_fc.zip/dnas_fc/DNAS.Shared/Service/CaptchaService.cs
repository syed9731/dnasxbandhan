﻿using DNAS.Application.Common.Implementation;
using DNAS.Application.IService;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Security.Cryptography;
using System.Text;

namespace DNAS.Shared.Service
{
    public class CaptchaService :ICaptchaService
    {
        public string GenerateRandomString(int length, CharType type)
        {
            if (length < 1)
                return string.Empty;
            Random autoRand = new Random();
            string randomStr = "";
            char[] myArray = new char[length];
            int x;
            StringBuilder bld = new StringBuilder();
            for (x = 0; x < length; x++)
            {
                myArray[x] = RandomChar(autoRand, type);
                bld.Append(myArray[x].ToString());
            }
            randomStr = bld.ToString();
            return randomStr;
        }
        /// <summary>
        /// Generate random char sequences
        /// </summary>
        /// <param name="autoRand">Random generator class</param>
        /// <returns></returns>

        private char RandomChar(Random autoRand, CharType type)
        {
            char c = '0';
            int start, end;
            if (type == CharType.MIX)
            {
                start = 1;
                end = 4;
            }
            else
            {
                start = 1;
                end = 2;
            }
            switch (autoRand.Next(start, end))
            {
                case 1:
                    c = Convert.ToChar(autoRand.Next(49, 58));

                    // excluding 0
                    break;
                case 2:
                    c = Convert.ToChar(autoRand.Next(65, 79));

                    // excluding o
                    break;
                case 3:
                    c = Convert.ToChar(autoRand.Next(80, 91));
                    break;
            }
            return c;
        }


        /// <summary>
        /// Generate random color
        /// </summary>
        /// <returns></returns>
        private Color RandomColor()
        {            
            return Color.FromArgb(RandomNumberGenerator.GetInt32(256), RandomNumberGenerator.GetInt32(256), RandomNumberGenerator.GetInt32(256));
        }
        /// <summary>
        /// Transparent background, you can change it if you want something else.
        /// </summary>
        /// <returns>Color</returns>
        private Color GetColor(string color)
        {
            if (color != "random" && !string.IsNullOrWhiteSpace(color))
                return Color.FromName(color);
            return RandomColor();
        }

        /// <summary>
        /// Generate random char sequences as a bitmap
        /// </summary>
        /// <param name="text">Random chars</param>
        /// <param name="width">Width of the captcha</param>
        /// <param name="height">Height of the captcha</param>
        /// <param name="fontFamily">Font of the captcha</param>
        /// <returns>Bitmap byte array</returns>
        /// 
        public byte[] CreateCAPTCHAImage(string text, string backgroundColor, string foreColor, int width = 120, int height = 40, string fontFamily = "Arial")
        {
            if (string.IsNullOrEmpty(text))
                return [];
            if (text.Length > 6)
                width += width / 4 * (text.Length - 6);


            Bitmap objBitmap = new Bitmap(width, height, PixelFormat.Format32bppPArgb);


            Graphics objGraphics = Graphics.FromImage(objBitmap);
            Rectangle objRectangle = new Rectangle(0, 0, width, height);
            objGraphics.SmoothingMode = SmoothingMode.HighQuality;


            using (SolidBrush objSolidBrush = new SolidBrush(GetColor(backgroundColor))) { objGraphics.FillRectangle(objSolidBrush, objRectangle); }
            Font objFont = new Font(fontFamily, 25, FontStyle.Regular);
            
            GraphicsPath objGraphicsPath = new GraphicsPath();
            StringFormat objStringFormat = new StringFormat();
            objStringFormat.Alignment = StringAlignment.Center;
            objStringFormat.LineAlignment = StringAlignment.Center;
            objGraphicsPath.AddString(text, objFont.FontFamily, (int)objFont.Style, objFont.Size, objRectangle, objStringFormat);


            SolidBrush objSolidBrushColor = new SolidBrush(GetColor(foreColor));
            objGraphics.FillPath(objSolidBrushColor, objGraphicsPath);
            #region Distortion
            //this code add ten random line in captcha image
            //Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                // calculate line start and end point here using the Random class:
                //int x0 = rnd.Next(0, width);
                //int y0 = rnd.Next(0, height);
                //int x1 = rnd.Next(0, width);
                //int y1 = rnd.Next(0, height);

                int x0 = RandomNumberGenerator.GetInt32(0, width);
                int y0 = RandomNumberGenerator.GetInt32(0, height);
                int x1 = RandomNumberGenerator.GetInt32(0, width);
                int y1 = RandomNumberGenerator.GetInt32(0, height);

                objGraphics.DrawLine(Pens.Gray, x0, y0, x1, x1);
            }
            //double distort = new Random().Next(3, 6) * (new Random().Next(3) == 1 ? 1 : -1);
            double distort = RandomNumberGenerator.GetInt32(3, 6) * (RandomNumberGenerator.GetInt32(3) == 1 ? 1 : -1);
            using (Bitmap copy = (Bitmap)objBitmap.Clone())
            {
                for (int waveY = 0; waveY < height; waveY++)
                {
                    for (int waveX = 0; waveX < width; waveX++)
                    {
                        int newX = (int)(waveX + (distort * Math.Sin(Math.PI * waveY / 56.0)));
                        int newY = (int)(waveY + (distort * Math.Cos(Math.PI * waveX / 44.0)));
                        if (newX < 0 || newX >= width)
                            newX = 0; if (newY < 0 || newY >= height) newY = 0;
                        objBitmap.SetPixel(waveX, waveY, copy.GetPixel(newX, newY));
                    }
                }
            }
            #endregion Distortion
            //objHttpContext.Response.ContentType = "image/png";
            //objBitmap.Save(this.Response.OutputStream, ImageFormat.Png);
            Byte[] data;

            using (var memoryStream = new MemoryStream())
            {
                objBitmap.Save(memoryStream, ImageFormat.Png);
                data = memoryStream.ToArray();
            }
            return data;
        }
    }
}
