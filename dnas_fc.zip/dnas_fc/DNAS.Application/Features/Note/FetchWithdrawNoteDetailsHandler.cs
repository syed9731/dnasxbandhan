﻿using DNAS.Application.Common.Interface;
using DNAS.Application.IRepository;
using DNAS.Domain.DTO.Note;
using DNAS.Domian.DTO.Note;
using MediatR;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;


namespace DNAS.Application.Features.Note
{
    public class FetchWithdrawNoteDetailsCommand(NoteModel note): IRequest<WithdrawNoteDetailsModel>
    {
        public NoteModel _note { get; set; } = note;
    }
    internal sealed class FetchWithdrawNoteDetailsHandler(INote iNote, ICustomLogger logger, IEncryption encryption, IHttpContextAccessor haccess) : IRequestHandler<FetchWithdrawNoteDetailsCommand, WithdrawNoteDetailsModel>
    {
        private readonly INote _iNote = iNote;
        public readonly ICustomLogger _logger = logger;
        private readonly IEncryption _encryption= encryption;
        private readonly string loginUserId = $"User_{haccess.HttpContext?.User.FindFirstValue("UserId")}";

        public async Task<WithdrawNoteDetailsModel> Handle(FetchWithdrawNoteDetailsCommand request, CancellationToken cancellationToken)
        {

            WithdrawNoteDetailsModel Response = new();
            try
            {
                var inparam = new
                {
                    @NoteId = Convert.ToInt64(request._note.NoteId),
                    @UserId= Convert.ToInt32(request._note.UserId)
                };
                Response = await _iNote.FetchWithdrawDetailsNote(inparam);                
                if (Response != null)
                {
                    Response.noteModel.NoteId = _encryption.AesEncrypt(Response.noteModel.NoteId.ToString());
                    if (Response.attachmentsModel.Any())
                    {
                        Response.attachmentsModel = Response.attachmentsModel.Select(e =>
                        {
                            e.AttachmentId = _encryption.AesEncrypt(e.AttachmentId);
                            return e;
                        }).ToList();
                    }
                    _logger.LogwriteInfo("Pending note data fetch successfully done", loginUserId);
                    return Response;
                }
                else
                {
                    _logger.LogwriteInfo("Pending note data fetch failed", loginUserId);
                    return new WithdrawNoteDetailsModel();
                }
                
            }
            catch (Exception ex)
            {
                _logger.LogwriteInfo("exception occur during FetchWithdrawNoteDetailsCommand execution--- message-" + Environment.NewLine+ex.Message+Environment.NewLine+ex.StackTrace, loginUserId);
                return Response;
            }

        }

    }
}
