﻿namespace DNAS.Application.Common.Interface
{
    public interface IFileValidation
    {
        bool CheckMimeType(string mimeType);
    }
}
